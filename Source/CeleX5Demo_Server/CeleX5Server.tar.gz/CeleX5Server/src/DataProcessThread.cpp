#include "../include/DataProcessThread.h"

XThread::XThread(const std::string threadName)
    : m_threadName(threadName)
    , m_threadID(0)
    , m_bRun(false)
    , m_bSuspended(false)
#ifndef _WIN32
    , m_mutex(PTHREAD_MUTEX_INITIALIZER)
    , m_cond(PTHREAD_COND_INITIALIZER)
#endif
{

}

XThread::~XThread()
{

}

//Create a thread and run (default) or hang
bool XThread::start(bool bSuspend/* = false*/)
{
    m_bRun = createThread(bSuspend);
    return m_bRun;
}

//Create a thread and run (default) or hang
bool XThread::createThread(bool bSuspend/* = false*/)
{
    if(!m_bRun)
    {
#ifdef _WIN32
        if(bSuspend)
        {
            m_handle = (HANDLE)_beginthreadex(NULL, 0, staticThreadFunc, this, CREATE_SUSPENDED, &m_threadID);
            m_bSuspended = true;
        }
        else
        {
            m_handle = (HANDLE)_beginthreadex(NULL, 0, staticThreadFunc, this, 0, &m_threadID);
        }
        m_bRun = (NULL != m_handle);
#else
        int status = pthread_create(&m_threadID, NULL, staticThreadFunc, this);
        if (status != 0)
            printf("creating thread failure\n");
        else
            m_bRun = true;
#endif
    }
    return m_bRun;
}

//If the waiting time (milliseconds) is negative, it means unlimited wait.
void XThread::join(int timeout/* = -1*/)
{
#ifdef _WIN32
    if(m_handle && m_bRun)
    {
        if(timeout < 0)
            timeout = INFINITE;
        ::WaitForSingleObject(m_handle, timeout);
    }
#else
#endif
}

//Resume the suspended thread
void XThread::resume()
{
    printf("%s%d%s%d","XThread::resume: m_bRun = \n",m_bRun,", m_bSuspended = ", m_bSuspended);
    if (m_bRun && m_bSuspended)
    {
        printf("XThread::resume\n");
#ifdef _WIN32
        ::ResumeThread(m_handle);
        m_bSuspended = false;
#else
        pthread_mutex_lock(&m_mutex);
        m_bSuspended = false;
        pthread_cond_signal(&m_cond);
        pthread_mutex_unlock(&m_mutex);
#endif
    }
}

//Suspend the thread
void XThread::suspend()
{
    if (m_bRun && !m_bSuspended)
    {
        printf("XThread::suspend\n");
#ifdef _WIN32
        m_bSuspended = true;
        ::SuspendThread(m_handle);
#else
        pthread_mutex_lock(&m_mutex);
        m_bSuspended = true;
        pthread_mutex_unlock(&m_mutex);
#endif
    }
}

//Terminate the thread
bool XThread::terminate()
{
#ifdef _WIN32
    unsigned long exitCode = 0;
    if(m_handle && m_bRun)
    {
        if (::TerminateThread(m_handle, exitCode))
        {
            ::CloseHandle(m_handle);
            m_handle = NULL;
            m_bRun = false;
            return true;
        }
        printf("XThread::terminate: exitCode = %ld\n", exitCode);
    }
#else
#endif
    return false;
}

bool XThread::isRunning()
{
    return m_bRun;
}

unsigned int XThread::getThreadID()
{
    return m_threadID;
}

std::string XThread::getThreadName()
{
    return m_threadName;
}

void XThread::setThreadName(std::string threadName)
{
    m_threadName = threadName;
}

#ifdef _WIN32
//Thread function
unsigned int XThread::staticThreadFunc(void* arg)
{
    XThread* pThread = (XThread*)arg;  //Get the thread class pointer
    pThread->run();

    return 0;
}
#else
//Thread function
void* XThread::staticThreadFunc(void* args)
{
    XThread* pThread = static_cast<XThread *>(args); //Get the thread class pointer
    if (pThread)
        pThread->run();
    return NULL;
}
#endif


int connect_fd = 0;
int listenfd = 0;
int send_ok = 0;

DataProcessThread::DataProcessThread(const std::string &name)
    : XThread(name)
{
    m_pData = new unsigned char[655360];
}

DataProcessThread::~DataProcessThread()
{
    delete[] m_pData;
    m_pData = NULL;
}

void DataProcessThread::addData(unsigned char *data, long length)
{
    if (connect_fd > 0)
    {
        m_queueData.push(data, length);
    }
    else
    {
        clearData();
    }
}

void DataProcessThread::clearData()
{
    m_queueData.clear();
    m_uiPackageNo = 0;
}

uint32_t DataProcessThread::queueSize()
{
    return m_queueData.size();
}

void DataProcessThread::setCeleX(CeleX5* pCelex5)
{
    m_pCelex5 = pCelex5;
}

void DataProcessThread::setLoopModeEnable(bool enable)
{
    m_bIsLoopMode = enable;
}

void DataProcessThread::createListenFd()
{
    printf("create socket and wait connect\n");
    //create listen socket
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0)
    {
        printf("create a new socket failed\n");
    }

    /* Enable address reuse */
    int on = 1;
    int ret = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

    //bind listen socket
    struct sockaddr_in bd_addr;
    memset(&bd_addr, 0, sizeof(bd_addr));
    bd_addr.sin_family = AF_INET;
    bd_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    bd_addr.sin_port = htons(SDK_PORT);
    while (bind(listenfd, (struct sockaddr *)&bd_addr, sizeof(sockaddr)) < 0)
    {
        printf("bind a socket failed\n");
        sleep(1);
    }

    //listen listen socket
    if (listen(listenfd, 1024) < 0)
    {
        printf("listen a socket failed\n");
    }
}

void DataProcessThread::run()
{
    createListenFd();

    while (m_bRun)
    {
        if (connect_fd == 0)
        {
            //wait connect to listen socket
            printf("wait connect...\n");

            if ((connect_fd = accept(listenfd, (struct sockaddr*)NULL, NULL)) <= 0)
            {
                printf("accpet socket error: %s errno :%d\n", strerror(errno), errno);
                sleep(1);
                connect_fd = 0;
                continue;
            }
        }

        while(1)
        {
            if (connect_fd <= 0)
            {
               break;
            }
            if (m_queueData.size() > 0)
            {
                //printf("%d\n", m_queueData.size());
                long dataLen = 0;
                m_queueData.pop(m_pData, &dataLen);

                if (dataLen > 0)
                {
                    if ((send(connect_fd, m_pData, 655360, MSG_DONTWAIT)) < 0)
                    {
                        printf("send mes error: %s errno : %d\n", strerror(errno), errno);
                        connect_fd = 0;
                        break;
                    }
                    usleep(10);
                }
            }
        }
    }
}
