#include "../include/DataQueue.h"

DataQueue::DataQueue(): m_size(0)
    , m_iHead(0)
    , m_iTail(0)
{
    for (int i = 0; i < m_arrayData.size(); i++)
    {
        m_arrayData[i].length = MAX_DATA_LEN;
        m_arrayData[i].pData = new unsigned char[MAX_DATA_LEN];
    }
}

DataQueue::~DataQueue()
{

}

void DataQueue::push(unsigned char *pData, long length)
{
    if (m_size == ARRAY_SIZE)
    {
        printf("data array is full! ");
        return;
    }
    int len_copy = length > MAX_DATA_LEN ? MAX_DATA_LEN : length;
    memcpy(m_arrayData[m_iTail].pData, pData, len_copy);
    m_arrayData[m_iTail].length = len_copy;
    m_size++;
    m_iTail++;
    if (m_iTail == ARRAY_SIZE)
        m_iTail = 0;
}

void DataQueue::pop(unsigned char *pData, long *length)
{
    if (m_size <= 0)
    {
        printf("data array is empty! ");
        return;
    }
    if (NULL == m_arrayData[m_iHead].pData)
    {
        //pData = NULL;
        *length = 0;
    }
    else
    {
        //pData = m_arrayData[m_iHead].pData;
        memcpy(pData, m_arrayData[m_iHead].pData, m_arrayData[m_iHead].length);
        *length = m_arrayData[m_iHead].length;
    }
    m_size--;
    m_iHead++;
    if (ARRAY_SIZE == m_iHead)
        m_iHead = 0;
}

unsigned long DataQueue::size()
{
    return m_size;
}

void DataQueue::clear()
{
    m_size = 0;
    m_iHead = 0;
    m_iTail = 0;
}
