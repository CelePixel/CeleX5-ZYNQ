#include "../include/CeleX5.h"
#include "../include/DataProcessThread.h"

CeleX5::CeleX5()
{
    m_pDataProcessThread = new DataProcessThread("CeleX5Thread");
    m_pDataProcessThread->setCeleX(this);
}

CeleX5::~CeleX5()
{
    if (m_pDataProcessThread)
    {
        delete m_pDataProcessThread;
        m_pDataProcessThread = NULL;
    }
}

void CeleX5::setSensorFixedMode(CeleX5Mode mode)
{
    clearData();
    enterCFGMode();
    //Write Fixed Sensor Mode
    wireIn(53, static_cast<uint32_t>(mode), 0xFF);
    enterStartMode();

}

void CeleX5::setLoopModeEnabled(bool enable)
{
    m_bIsEnterLoopMode=enable;
    enterCFGMode();
    if (enable)
    {
        wireIn(64, 1, 0xFF);
    }
    else
    {
        wireIn(64, 0, 0xFF);
    }
    enterStartMode();

}

bool CeleX5::isLoopModeEnabled()
{
    return m_bIsEnterLoopMode;
}

void CeleX5::setClockRate(uint32_t value)
{
    if (value > 100 || value < 20)
        return;

    enterCFGMode();

    // Disable PLL
    wireIn(150, 0, 0xFF);
    // Write PLL Clock Parameter
    wireIn(159, value * 3 / 5, 0xFF);
    // Enable PLL
    wireIn(150, 1, 0xFF);

    enterStartMode();
}

void CeleX5::setSensorLoopMode(CeleX5Mode mode, int loopNum)
{
    if (loopNum < 1 || loopNum > 3)
    {
        printf("CeleX5::setSensorMode: wrong loop number!\n");
        return;
    }
    clearData();
    enterCFGMode();
    wireIn(52 + loopNum, static_cast<uint32_t>(mode), 0xFF);
    enterStartMode();
}

void CeleX5::setThreshold(uint32_t value)
{
    enterCFGMode();

    int EVT_VL = 512 - value;
    if (EVT_VL < 0)
        EVT_VL = 0;
    writeRegister(2, -1, 3, EVT_VL);

    int EVT_VH = 512 + value;
    if (EVT_VH > 1023)
        EVT_VH = 1023;
    writeRegister(6, -1, 7, EVT_VH);

    enterStartMode();
}

void CeleX5::setBrightness(uint32_t value)
{
    enterCFGMode();
    writeRegister(22, -1, 23, value);
    enterStartMode();
}

void CeleX5::setEventDuration(uint32_t value)
{
    enterCFGMode();

    value = value * 1000 / 655;

    uint32_t valueH = value >> 8;
    uint32_t valueL = 0xFF & value;

    wireIn(58, valueH, 0xFF);
    wireIn(57, valueL, 0xFF);

    enterStartMode();
}

void CeleX5::setPictureNumber(uint32_t num, CeleX5Mode mode)
{
    enterCFGMode();

    if (Full_Picture_Mode == mode)
        wireIn(59, num, 0xFF);
    else if (Full_Optical_Flow_S_Mode == mode)
        wireIn(60, num, 0xFF);
    else if (Full_Optical_Flow_M_Mode == mode)
        wireIn(62, num, 0xFF);

    enterStartMode();
}

void CeleX5::setISO(uint32_t value)
{
    int index = value - 1;
    if (index < 0)
        index = 0;
    if (index > 5)
        index = 5;

    int col_gain[6] = { 2, 2, 2, 2, 1, 1 };
    int bias_advl_i[6] = { 470, 410, 350, 290, 410, 380 };
    int bias_advh_i[6] = { 710, 770, 830, 890, 770, 800 };
    int bias_advcl_i[6] = { 560, 545, 530, 515, 545, 540 };
    int bias_advch_i[6] = { 620, 635, 650, 665, 635, 640 };
    int bias_vcm_i[6] = { 590, 590, 590, 590, 590, 590 };

    enterCFGMode();

    writeRegister(CSR_COL_GAIN, -1, -1, col_gain[index]);
    writeRegister(CSR_BIAS_ADVL_I_H, -1, CSR_BIAS_ADVL_I_L, bias_advl_i[index]);
    writeRegister(CSR_BIAS_ADVH_I_H, -1, CSR_BIAS_ADVH_I_L, bias_advh_i[index]);
    writeRegister(CSR_BIAS_ADVCL_I_H, -1, CSR_BIAS_ADVCL_I_L, bias_advcl_i[index]);
    writeRegister(CSR_BIAS_ADVCH_I_H, -1, CSR_BIAS_ADVCH_I_L, bias_advch_i[index]);

    writeRegister(42, -1, 43, bias_vcm_i[index]);

    enterStartMode();
}

void CeleX5::wireIn(uint32_t address, uint32_t value, uint32_t mask)
{
    camera_register_buffer buffer;
    buffer.address = address;
    buffer.value   = value;
    buffer.mask    = mask;
    if (ioctl(m_iFileDescriptor, CAMERA_SET_REGISTER, &buffer) == 0)
    {
        printf("%s%d%s%d\n","CeleX5::wireIn: address = ",address,", value = ",value);
    }
}

void CeleX5::clearData()
{
    printf("------reset------\n");
    m_pDataProcessThread->clearData();
}

void CeleX5::enterCFGMode()
{
    wireIn(93, 0, 0xFF);
    wireIn(90, 1, 0xFF);
}

void CeleX5::enterStartMode()
{
    wireIn(90, 0, 0xFF);
    wireIn(93, 1, 0xFF);
}

void CeleX5::writeRegister(int16_t addressH, int16_t addressM, int16_t addressL, uint32_t value)
{
    if (addressL == -1)
    {
        wireIn(addressH, value, 0xFF);
    }
    else
    {
        if (addressM == -1)
        {
            uint32_t valueH = value >> 8;
            uint32_t valueL = 0xFF & value;
            wireIn(addressH, valueH, 0xFF);
            wireIn(addressL, valueL, 0xFF);
        }
    }
}

bool CeleX5::openSensor()
{
    m_iFileDescriptor = open("/dev/axidma", O_RDWR|O_EXCL);
    if (m_iFileDescriptor > 0)
    {
        /*if ((int)sensorMode <= 2) //event mode
        {
            m_uiDMABufferSize = 1280 * 32 * 4;
        }
        else //full-frame mode
        {
            //m_ImageBuffersize =  (PIXELS_NUMBER + 4)<<1;
            m_uiDMABufferSize = 1280 * 128 * 4;
        }*/
        m_uiDMABufferSize = 1280 * 128 * 4;
        //m_uiDMABufferSize = 4096000;
        printf("-------------- m_uiDMABufferSize = %d\n", m_uiDMABufferSize);

        m_pDataToRead = (uint8_t*)mmap(nullptr, m_uiDMABufferSize<<1, PROT_READ|PROT_WRITE, MAP_SHARED, m_iFileDescriptor, 0);
        if (m_pDataToRead != nullptr)
        {
            m_pDataProcessThread->start();
            return true;
        }
    }
    close(m_iFileDescriptor);
    return false;
}

bool CeleX5::getSensorData(unsigned char* buffer)
{
    struct axidma_transaction trans;
    trans.timeout = 2000;      // wait time out;
    trans.channel_id = 1;      // The id of the DMA channel to use
    trans.buf = m_pDataToRead; // The buffer used for the transaction
    trans.buf_len = m_uiDMABufferSize << 1; // The length of the buffer
    trans.period_len = m_uiDMABufferSize;
    // setBrightness(260);
    //usleep(100000);
    if (ioctl(m_iFileDescriptor, AXIDMA_DMA_READ, &trans) == 0)
    {
        //cout << "--- CeleX5::getSensorData: Begin" << endl;
        //m_pDataProcessThread->addData(m_pDataToRead, m_uiDMABufferSize);
        //cout << "--- CeleX5::getSensorData: buffer size = " << m_uiDMABufferSize << endl;
        return true;
    }
    return false;
}

int CeleX5::getBufpos()
{
    if (ioctl(m_iFileDescriptor, CAMERA_GET_BUFPOS, &testvalue) !=  0)
    {
        printf("get bufpos failure!\n");
        return -1;
    }
    return testvalue;
}

uint8_t* CeleX5::getImagedata(int pos)
{
    if (pos==0)
    {
        m_pDataProcessThread->addData(m_pDataToRead,m_uiDMABufferSize);
        return m_pDataToRead;
    }
    if (pos==1)
    {
        m_pDataProcessThread->addData(m_pDataToRead+m_uiDMABufferSize,m_uiDMABufferSize);
        return (m_pDataToRead+m_uiDMABufferSize);
    }
}

int CeleX5::setfcntl()
{
    int flags;
    printf("1===============\n");
    fcntl(m_iFileDescriptor, F_SETOWN, getpid());
    printf("2===============\n");
    flags = fcntl(m_iFileDescriptor, F_GETFL);
    printf("3===============\n");
    fcntl(m_iFileDescriptor, F_SETFL, flags | FASYNC);
    printf("4===============\n");
    return flags;
}
