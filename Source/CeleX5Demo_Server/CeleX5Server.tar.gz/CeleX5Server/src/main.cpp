#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <semaphore.h>
#include "../include/socketcfg.h"
#include "../include/CeleX5.h"
#include <stdio.h>

#include <semaphore.h>
#include <signal.h>

typedef struct
{
    int cmd;
    int value;
    int value2;
} PACKET_RQ;

extern int connect_fd;
extern int listenfd;
extern int send_ok;

PACKET_RQ packet_req;

CeleX5 celex5;

void* cmd_req_entry(void *para)
{
    while (1)
    {
        //printf("connect_fd = %d\n", connect_fd);
        if (connect_fd > 0)
        {
            if (recv(connect_fd, &packet_req, sizeof(PACKET_RQ), 0) > 0)
            {
                printf("packet cmd=%d, value=%d, value2=%d.\n", packet_req.cmd, packet_req.value, packet_req.value2);
                if (CMD_SET_FIXED_MODE == packet_req.cmd)
                {
                    celex5.setSensorFixedMode(CeleX5::CeleX5Mode(packet_req.value));
                }
                else if (CMD_ENABLE_LOOP_MODE == packet_req.cmd)
                {
                    celex5.setLoopModeEnabled(packet_req.value);
                }
                else if (CMD_SET_LOOP_MODE == packet_req.cmd)
                {
                    if (celex5.isLoopModeEnabled())
                    {
                        celex5.setSensorLoopMode(CeleX5::CeleX5Mode(packet_req.value),packet_req.value2); //loop mode, loop num
                    }
                }
                else if (CMD_SET_BRIGHTNESS == packet_req.cmd)
                {
                    celex5.setBrightness(packet_req.value);
                }
                else if (CMD_SET_THRESHOLD == packet_req.cmd)
                {
                    celex5.setThreshold(packet_req.value);
                }
                else if (CMD_SET_CLOCK == packet_req.cmd)
                {
                    celex5.setClockRate(packet_req.value);
                }
                else if (CMD_SET_LOOP_EVENT_DURATION == packet_req.cmd)
                {
                    celex5.setEventDuration(packet_req.value);
                }
                else if (CMD_SET_LOOP_FULL_PIC_NUM == packet_req.cmd)
                {
                    CeleX5::CeleX5Mode val2 = static_cast<CeleX5::CeleX5Mode>(packet_req.value2);
                    celex5.setPictureNumber(packet_req.value, val2);
                }
                else if (CMD_SET_LOOP_S_FO_PIC_NUM == packet_req.cmd)
                {
                    CeleX5::CeleX5Mode val2 = static_cast<CeleX5::CeleX5Mode>(packet_req.value2);
                    celex5.setPictureNumber(packet_req.value, val2);
                }
                else if (CMD_SET_LOOP_M_FO_PIC_NUM == packet_req.cmd)
                {
                    CeleX5::CeleX5Mode val2 = static_cast<CeleX5::CeleX5Mode>(packet_req.value2);
                    celex5.setPictureNumber(packet_req.value, val2);
                }
                else if (CMD_SET_ISO == packet_req.cmd)
                {
                    celex5.setISO(packet_req.value);
                }
                else if (CMD_RESET == packet_req.cmd)
                {
                    celex5.clearData();
                }
                else if (CMD_CLIENT_EXIT == packet_req.cmd)
                {
                    connect_fd = 0;
                }
            }
            else
            {
                printf("recv mes error: %s errno : %d\n", strerror(errno), errno);
                if (errno > 0)
                {
                    connect_fd = 0;
                }
            }
        }
        usleep(1000);
    }
}


sem_t sem;
int value;

void catch_signal(int sign)
{
    switch (sign)
    {
    case SIGINT:
    case SIGTERM:
    case SIGABRT:
        printf("SIGINT is signaled!\n");
        break;

    case SIGIO:
        sem_post(&sem);
        sem_getvalue(&sem, &value);
        //printf("SIGIO is signaled!\n");
        //printf("SIGIO sem value = %d\n",value);
        //exit(0);
        break;
    }
}

struct sigaction s;

int main(int argc, char* argv[])
{
    printf("--------------- CeleX5Demo ZYNQ 2019-07-10 ---------------\n");

    if (!celex5.openSensor())
    {
        printf("---------------- open sensor error!\n");
        return -1;// to do
    }
    celex5.setSensorFixedMode(CeleX5::Event_Address_Only_Mode);

    memset(&s, 0, sizeof(s));
    s.sa_handler = catch_signal;
    s.sa_flags = SA_RESTART;
    sigaction(SIGIO, &s, NULL);
    sigaction(SIGINT, &s, NULL);
    sigaction(SIGTERM, &s, NULL);
    sigaction(SIGABRT, &s, NULL);

    //sigaction(SIGINT,&s, NULL);

    int res = sem_init(&sem, 0, 0);

    if (res == -1)
    {
        printf("sem init fail.\n");
    }

    printf("fcntl before\n");
    celex5.setfcntl();
    printf("fcntl after\n");

    pthread_t tid2;
    int err = pthread_create(&tid2, NULL, cmd_req_entry, NULL);
    if (err != 0)
    {
        perror("create cmd_req_entry failed.\n");
        return err;
    }

    if (celex5.getSensorData(nullptr))
    {
        printf("get pic successfully !!!!!!!!!!!!!!!!\n");

    }
    else
    {
        printf("get pic failed !!!!!!!!!!!!!!!!\n");
    }

    while (1)
    {
        sem_wait(&sem);
        if (connect_fd > 0)
        {
            int pos = celex5.getBufpos();
            celex5.getImagedata(pos);
        }
//        usleep(10);
    }
    return 0;
}
