#ifndef DATAPROCESSTHREAD_H
#define DATAPROCESSTHREAD_H

#include <string>
#include "DataQueue.h"
#include <vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>
#include <stdio.h>
#include <unistd.h>
#include "socketcfg.h"
#include "CeleX5.h"

#ifdef _WIN32
#include <windows.h>
#include <process.h>
#else
#include <pthread.h>
#endif

#define SDK_PORT   1234


class XThread
{
public:
    XThread(const std::string threadName = "newthread");
    virtual ~XThread();

    virtual void run() = 0;
    virtual bool start(bool bSuspended = false);

    void join(int timeout = -1);
    void resume();
    void suspend();
    bool terminate();
    bool isRunning();

    unsigned int getThreadID();
    std::string getThreadName();
    void setThreadName(std::string threadName);

private:
    bool createThread(bool bSuspended = false);
#ifdef _WIN32
    static unsigned int WINAPI staticThreadFunc(void* args);
#else
    static void* staticThreadFunc(void* args);
#endif

protected:
    std::string           m_threadName;
    volatile bool         m_bRun;
    bool                  m_bSuspended;

#ifdef _WIN32
    HANDLE                m_handle;
    unsigned int          m_threadID;
#else
    pthread_t             m_threadID;
    pthread_mutex_t       m_mutex;
    pthread_cond_t        m_cond;
#endif
};

class DataProcessThread: public XThread
{
public:
    DataProcessThread(const std::string& name);
    virtual ~DataProcessThread();

    void addData(unsigned char* data, long length);
    void clearData();
    uint32_t queueSize();
    void setCeleX(CeleX5* pCelex5);

protected:
    void run() override;

private:
    void setLoopModeEnable(bool enable);

private:
    CeleX5*                             m_pCelex5;
    unsigned char*                      m_pData;
    DataQueue                           m_queueData;
    std::queue<std::vector<uint8_t>>    m_queueVecData;
    uint32_t                            m_uiPackageNo;
    bool                                m_bIsLoopMode;

};

#endif // DATAPROCESSTHREAD_H
