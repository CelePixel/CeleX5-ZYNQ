#ifndef CELEX5_H
#define CELEX5_H

#include <stdint.h>
#include "../driver/axidma_ioctl.h"
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fstream>

#define CSR_COL_GAIN          45

#define CSR_BIAS_ADVL_I_H     30
#define CSR_BIAS_ADVL_I_L     31
#define CSR_BIAS_ADVH_I_H     26
#define CSR_BIAS_ADVH_I_L     27

#define CSR_BIAS_ADVCL_I_H    38
#define CSR_BIAS_ADVCL_I_L    39
#define CSR_BIAS_ADVCH_I_H    34
#define CSR_BIAS_ADVCH_I_L    35

class DataProcessThread;
class CeleX5
{
public:

    enum CeleX5Mode
    {
        Unknown_Mode = -1,
        Event_Address_Only_Mode = 0,
        Event_Optical_Flow_Mode = 1,
        Event_Intensity_Mode = 2,
        Full_Picture_Mode = 3,
        Full_Optical_Flow_S_Mode = 4,
        Full_Optical_Flow_Test_Mode = 5,
        Full_Optical_Flow_M_Mode = 6
    };

    enum emEventPicType
    {
        EventBinaryPic = 0,
        EventAccumulatedPic = 1,
        EventGrayPic = 2,
        EventCountPic = 3
    };

    enum emFullPicType
    {
        Full_Optical_Flow_Pic = 0,
        Full_Optical_Flow_Speed_Pic = 1,
        Full_Optical_Flow_Direction_Pic = 2
    };

    CeleX5();
    virtual ~CeleX5();

    void setSensorFixedMode(CeleX5Mode mode);

    void setLoopModeEnabled(bool enable);

    bool isLoopModeEnabled();

    void setSensorLoopMode(CeleX5Mode mode, int loopNum); //LopNum = 1/2/3

    void setThreshold(uint32_t value);

    void setBrightness(uint32_t value);

    void setClockRate(uint32_t value); //unit: MHz

    void setEventDuration(uint32_t value);

    void setPictureNumber(uint32_t num, CeleX5Mode mode);

    void setISO(uint32_t value);

    bool openSensor();

    bool getSensorData(unsigned char* buffer);

    int getBufpos();

    uint8_t* getImagedata(int pos);

    int setfcntl();

    void clearData();

protected:

private:

    void wireIn(uint32_t address, uint32_t value, uint32_t mask);
    void enterCFGMode();
    void enterStartMode();
    void writeRegister(int16_t addressH, int16_t addressM, int16_t addressL, uint32_t value);


    int                 m_iFileDescriptor;
    uint32_t            m_uiDMABufferSize;
    uint8_t*            m_pDataToRead;
    int                 testvalue;
    DataProcessThread*  m_pDataProcessThread;
    bool                m_bIsEnterLoopMode;
};

#endif // CELEX5_H
