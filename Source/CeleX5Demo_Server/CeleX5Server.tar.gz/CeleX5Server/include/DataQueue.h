#ifndef DATAQUEUE_H
#define DATAQUEUE_H

#include <queue>
#include <stdint.h>
#include <array>
#include <string.h>

#define ARRAY_SIZE    200
#define MAX_DATA_LEN  655360

typedef struct DataInfo
{
    unsigned char* pData;
    unsigned long  length;
} DataInfo;

class DataQueue
{
public:
    DataQueue();
    virtual ~DataQueue();
    void push(unsigned char* pData, long length);
    void pop(unsigned char* pData, long* length);
    unsigned long size();
    void clear();

protected:

private:
    std::queue<DataInfo> m_queue;
    std::array<DataInfo, ARRAY_SIZE> m_arrayData;
    unsigned long        m_size;
    int                  m_iHead;
    int                  m_iTail;
};

#endif // DATAQUEUE_H
